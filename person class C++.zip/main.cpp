/********************************************************************************
* main.cpp: Demonstration av klass i C++ f�r lagring samt utskrift av persondata.
********************************************************************************/
#include "person.hpp"
#include <clocale>
#include <fstream>

/********************************************************************************
* main: Lagrar personuppgifter f�r tv� personer och skriver ut i terminalen.
********************************************************************************/
int main(void)
{
   setlocale(LC_ALL, "Swedish");

   person p1("Erik Pihl", 31, "L�rdomsgatan 3", "Teacher", gender::male);
   person p2("Donald Duck", 88, "1313 Webfoot Street", "Comical character", gender::male);
   std::ofstream ostream("persons.txt", std::ios::out);

   p1.print();
   p2.print();

   p1.print(ostream);
   p2.print(ostream);

   return 0;
}